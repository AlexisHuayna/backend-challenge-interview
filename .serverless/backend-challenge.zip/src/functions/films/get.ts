import { NestFactory } from '@nestjs/core';
import { Handler, Context, APIGatewayProxyEvent } from 'aws-lambda';
import { AppModule } from 'src/app.module';
import { AppService } from 'src/app.service';

export const handler: Handler = async (
  event: APIGatewayProxyEvent,
  context: Context,
) => {
    const { id } = event.pathParameters;



  const appContext = await NestFactory.createApplicationContext(AppModule);

  const myObject = {
    name: 'John Doe',
    some: 25,
  };

  const other = appContext.get(AppService).getHello(myObject);

  return {
        isBase64Encoded: false,
        statusCode: 400,
        headers: {},
        body: JSON.stringify(other),
      };
  

//   const swapiProvider = appContext.get(SwapiProvider);


//     const film = await swapiProvider.getFilm(id);

//     const filmParsed = traslatorProvider.parseFilm(film);

//   return {
//     isBase64Encoded: false,
//     statusCode: 400,
//     headers: {},
//     body: 'NOT FOUND',
//   };
};
