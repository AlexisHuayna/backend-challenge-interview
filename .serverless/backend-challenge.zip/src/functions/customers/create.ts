import { NestFactory } from '@nestjs/core';
import { Handler, Context, APIGatewayProxyEvent } from 'aws-lambda';
import { AppModule } from 'src/app.module';

export const handler: Handler = async (event: APIGatewayProxyEvent, context: Context) => {
   const appContext = await NestFactory.createApplicationContext(AppModule);

   //const orderService = appContext.get(OrderService);
   
};
